import torch
import torch.nn.functional as F
import numpy as np
import os, argparse
from scipy import misc
from lib.pvt import PolypPVT
from utils.dataloader import test_dataset
from torch.nn.parallel import DataParallel
import torchvision.transforms as transforms
import numpy as np
import cv2
import matplotlib.pyplot as plt
def mask_reference_point( H, W, device):
    ref_x, ref_y = torch.meshgrid(torch.linspace(0, H - 1, H, dtype=torch.float32, device=device),
                                      torch.linspace(0, W - 1, W, dtype=torch.float32, device=device))
    ref = torch.cat((ref_y[..., None], ref_x[..., None]), -1)
    return ref

def oriented_derivative_learning(features, gt_masks):
    features = F.interpolate(features, scale_factor=8, mode='bilinear') 
    N,C,H, W = gt_masks.shape
    direction_nums =8
    features_after_sample = features.new_zeros((N, direction_nums, H, W))
    grids = mask_reference_point(H, W, device=features.device)
    grids = grids[None, :, :, :, None]
    grids = grids.repeat(N, 1, 1, 1, direction_nums)
    grids_offsets = torch.tensor([[-1, -1, -1, 0, 1, 1, 1, 0], [-1, 0, 1, 1, 1, 0, -1, -1]], dtype=features.dtype,
                                     device=features.device)
    grids_offsets = grids_offsets.repeat(N, H, W, 1, 1)
    offsets = grids_offsets
    grids = grids + offsets
    inputs = gt_masks
    for num in range(direction_nums):
        per_direction_grids = grids[:, :, :, :, num]
        per_direction_grids=per_direction_grids*2/(H-1)-1
        features_after_sample[:, num:num + 1, :, :] = F.grid_sample(inputs, per_direction_grids, mode='bilinear',
                                                                        align_corners=False, padding_mode='border')
    extend_gt_masks = gt_masks.repeat(1, direction_nums, 1, 1)
    extend_gt_masks = extend_gt_masks - features_after_sample
    oriented_gt = torch.zeros_like(extend_gt_masks)
    for num in range(direction_nums):
        offset = offsets[:, :, :, :, num]
        dis = torch.rsqrt(
            torch.square(offset[:, :, :, 0]) + torch.square(offset[:, :, :, 1]) + torch.full(offset[:, :, :, 0].shape,1e-5,device=offset[:,:,:,0].device))
        dis = dis[:, None, :, :]
        oriented_gt[:, num:num + 1, :, :] = (extend_gt_masks[:, num:num + 1, :, :] + 1e-5).mul(dis)
    od_loss = F.smooth_l1_loss(features, oriented_gt , reduction="mean")
    print(od_loss)
    return extend_gt_masks
def draw_features(w,h,x,savename):
    fig=plt.figure(figsize=(16,16))
    fig.subplots_adjust(left=0.05,right=0.95,bottom=0.05,top=0.95,wspace=0.05)
    for i in range(w*h):
        plt.subplot(h,w,i+1)
        plt.axis('off')
        img=x[0,i,:,:]
        #pmin=np.min(img)
        #pmax=np.max(img)
        #img=((img-pmin)/(pmax-pmin+1e-9))*255
        #img=img.astype(np.uint8)
        #img=cv2.applyColorMap(img,cv2.COLORMAP_JET)
        #img=img[:,:,::-1]
        plt.imshow(img*10,cmap='RdBu',vmin=-1,vmax=1)
    fig.savefig(savename,dpi=100)
    fig.clf()
    plt.close()
def get_pred_od():
    model=PolypPVT()
    model=DataParallel(model,device_ids=[0,1,2])
    model_pth="/root/share/LiYuKe/Polyp-PVT-main/model_pth/PolypPVT/99PolypPVT.pth"
    model.load_state_dict(torch.load(model_pth))
    model.cuda()
    model.eval()
    for _data_name in ['CVC-300','CVC-ClinicDB','Kvasir','CVC-ColonDB','ETIS-LaribPolypDB']:
        data_path='./dataset/TestDataset/{}'.format(_data_name)
        save_path='./sum_od/PolypPVT/{}/'.format(_data_name)
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        image_root='{}/images/'.format(data_path)
        gt_root='{}/masks/'.format(data_path)
        num1=len(os.listdir(gt_root))
        test_loader=test_dataset(image_root,gt_root,352)
        for i in range(num1):
            image,gt,name=test_loader.load_data()
            transf=transforms.ToTensor()
            gt=transf(gt)
            c, h, w = gt.shape
            gt=gt.reshape(1,c,h,w)
            gt=F.interpolate(gt,size=(352,352),mode='bilinear',align_corners=False)
            gt=gt.cuda()
            image=image.cuda()
            P1,P2,pred_od=model(image)
            oriented_gt=oriented_derivative_learning(pred_od,gt)
            pred_od=F.interpolate(pred_od,scale_factor=8,mode='bilinear',align_corners=False)
            N,C,H,W=pred_od.shape
            P1=F.interpolate(P1,size=(H,W),mode='bilinear',align_corners=False)
            K=F.sigmoid(P1)
            ATT=1-torch.cos(2*np.pi*K)
            draw_features(4,2,pred_od.cpu().detach().numpy(),save_path+name)
        print(_data_name, 'Finish!')
get_pred_od()